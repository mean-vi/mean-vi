import { Component } from '@angular/core';
import { Observable, of, throwError } from 'rxjs';/*  */
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { CommonService } from  './common.service'
import { apiService } from  './api.service'


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  title = 'myApp';

  constructor(
	  private http: HttpClient,
	  private commonService:CommonService,
	  private apiService:apiService
){
	this.submit();
}

	// files: any[] = [];
	// filesData:any;
	// formModel:any={};
	// name: string = '';

	// user = {
	// 	userName: '',
	// 	password: '',
	// 	confirmPassword: ''
	//   };

	// onFileDropped($event) {
	//   this.prepareFilesList($event);
	// }
  
	
	// fileBrowseHandler(files) {
	//   this.prepareFilesList(files);
	// }
  
	// prepareFilesList(files: Array<any>) {
	//   for (const item of files) {
	// 	this.files.push(item);
	//   }
	// }
  
	submit(){

		// console.log(this.name);

		// let data = new FormData();
		// var i=0;
		// this.files.forEach(element => {
		// 	data.append('document[]', this.files[i]);	
		// 	i++;
		// });
		let requestObject = {
			'Name' : 'test',
			'Address' : 'test address',
			'Country' : 'In',
			'Phone' :	85285285,
		}
		this.apiService.createUser(requestObject).subscribe((data) => {
			console.log(data);
		})

	}
	
	ngOnInit(): void {
	}
  
}
