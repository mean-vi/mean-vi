import { Injectable } from '@angular/core';

import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of, throwError } from 'rxjs';/*  */
import { map, catchError, timeout } from 'rxjs/operators';

import { CommonService } from  './common.service'

@Injectable()
export class apiService {

	constructor(
		private http: HttpClient, 
		private commonService:CommonService

	) { }

	createUser(data): Observable<any> {
		return this.commonService.post("customer", data);
	}
}
