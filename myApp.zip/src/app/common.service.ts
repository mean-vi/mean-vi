import { Injectable } from '@angular/core';

import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of, throwError } from 'rxjs';/*  */
import { map, catchError, timeout } from 'rxjs/operators';


const API_URL = 'http://localhost:3000/';



@Injectable()
export class CommonService {


	constructor(private http: HttpClient, ) { }

	postWithoutToken(url, data): Observable<any> {

		const httpHeaders = new HttpHeaders();
		httpHeaders.set('Cotent-Type', 'application/json');

		return this.http.post<any>(API_URL + url, data, { headers: httpHeaders });

	}

	get(url): Observable<any> {
		const header = new HttpHeaders(
			{
				"Content-Type": "application/json",
//				"Authorization": localStorage.getItem(environment.authTokenKey)
			}
		);
		return this.http.get(API_URL + url, { headers: header });
	}




	getWithoutToken(url): Observable<any> {
		const header = new HttpHeaders(
			{
				"Content-Type": "application/json",
			}
		);
		return this.http.get(API_URL + url, { headers: header });
	}

	post(url, data): Observable<any> {
		const header = new HttpHeaders(
			{
				"Content-Type": "application/json",
//				"Authorization": localStorage.getItem(environment.authTokenKey)
			}
		);
		return this.http.post(API_URL + url, data, { headers: header });
	}
	postIcheck(url, data): Observable<any> {
		const header = new HttpHeaders(
			{
				"Content-Type": "application/json",
//				"Authorization": localStorage.getItem(environment.authTokenKey)
			}
		);
		return this.http.post(API_URL + url, data, { headers: header });
	}

	postwithFormData(url, data): Observable<any> {
		const header = new HttpHeaders(
			{
				//"Authorization": localStorage.getItem(environment.authTokenKey)
			}
		);
		return this.http.post(API_URL + url, data, { headers: header });
	}

	put(url, data): Observable<any> {
		const header = new HttpHeaders(
			{
				"Content-Type": "application/json",
//				"Authorization": localStorage.getItem(environment.authTokenKey)
			}
		);
		return this.http.put(API_URL + url, data, { headers: header });
	}

	delete(url): Observable<any> {
		const header = new HttpHeaders(
			{
				"Content-Type": "application/json",
//				"Authorization": localStorage.getItem(environment.authTokenKey)
			}
		);
		return this.http.delete(API_URL + url, { headers: header });
	}
}
